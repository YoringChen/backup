import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'

export default class Hello extends Component {
  render () {
    return (<View>分包测试全局组件</View>)
  }
}
